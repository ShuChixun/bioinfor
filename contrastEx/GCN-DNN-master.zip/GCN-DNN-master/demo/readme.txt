This a demo of GCN-DNN
Firstly, drugnet_and_feature.R and proteinnet_and_feature.R should be run. They can generate drug feature and network and protein feature and network.
Then, sd_demo.R ,st_demo.R  and sp_demo.R can be run. 


demodata.txt demo of DrugBank data
drug_detail2.txt is the detailed information for each drug. include : categories, InChIKey, Interactive drugs, proteins
protein_feature_26.txt is the  sequence feature for each protein
protein_interact.txt is the interactions between proteins. 

